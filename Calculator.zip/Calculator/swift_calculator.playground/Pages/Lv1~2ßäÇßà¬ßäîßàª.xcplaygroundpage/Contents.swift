//: [Previous](@previous)

/*import Foundation

var greeting = "Hello, playground"*/

//: [Next](@next)

//함수 파라미터로 숫자를 직접 입력
/*let calculator = Calculator()
 let addResult = calculator.calculate(oprator: "+", firstNumber: 10, secondNumber: 20 */

/*Lv1: 더하기, 빼기, 나누기, 곱하기 연산 수행가능한
 생성된 클래스 이유하여 연산진행후 출력
 오류날수있는 예외처리 상황 고민+구현*/


/*Lv2: 나머지 연산 코드 추가, 연산진행후 출력
 오류날수있는 예외처리 상황 고민+구현*/
 
 /*Lv3: 아래 각각의 클래스들을 만들고 클래스간의 관계를 고려하여 Calculator 클래스와 관계 맺기
  [ ] AddOperation(더하기)
  [ ] SubstractOperation(빼기)
  [ ] MultiplyOperation(곱하기)
  [ ] DivideOperation(나누기)
  [ ] Calculator 클래스의 내부코드를 변경
  [ ] 관계를 맺은 후 필요하다면 별도로 만든 연산 클래스의 인스턴스를 Calculator 내부에서 사용
  Lv2 와 비교하여 어떠한 점이 개선 되었는지 스스로 생각해 봅니다.
  hint. 클래스의 책임(단일책임원칙)
*/

/*test1: class Calculaotor {
    func add(num1: Int, num2: Int) -> Int {
        return num1 + num2
    }
}
// test
var add2 = plus(num1: 3, num2: 4)
// 실행X */

/*test2:
class Calculaotor {
    var num1: Int
    var num2: Int
    init(num1: Int, num2: Int) {
        self.num1 = num1
        self.num2 = num2
    }
}
let calculaotor = Calculaotor(num1:3, num2:4)
print(num1 + num2)*/

//실행x


/*test3
 class Calculaotor {
    var num1: Int
    var num2: Int
    init() {
        self.num1 = 3
        self.num2 = 12
    }
}
var add: Int() -> Int {
    return num1 + num2
}*/

/* test 4
class Calculaotor {
    var num1: Int
    var num2: Int
    init(num: Int, num2:Int) {
        self.num1 = num1
        self.num2 = num2
    }
    func add() {
        print(num1 + num2)
    }
}
 값이 없는데 init으로 초기화 해서 안되는건지*/


//test1: 2차보안
//더하기 실행완료되어 다른 함수도 추가
class Calculaotor {
    func add(num1: Int, num2: Int) -> Int {
        return num1 + num2
    }
    func add(num1: Double, num2: Double) -> Double {
        return num1 + num2 //소숫점 더하기 추가
    }
        func sub(num1: Int, num2: Int) -> Int {
            return num1 - num2
        }
  func sub(num1: Double, num2: Double) -> Double {
        return num1 - num2 //소숫점 빼기 추가
    }
    func mul(num1: Int, num2: Int) -> Int {
        return num1 * num2
    }
    func mul(num1: Double, num2: Int) -> Double {
        return Double(num1) * Double(num2)//소숫점에 정수 곱하기 추가
    }
    func div(num1: Int, num2: Int) -> Double {
        return Double(num1) / Double(num2)
    }
    /*  나누기는 정수로 안나눠 떨어질때가 많아서 소숫점으로 구현하려함
      Int 타입을 Double 타입으로 반환하려하니 오류발생
    질문을 통해 반환값 또한 Double로 변경해주었더니 정상출력*/
    
    func rest(num1: Int, num2: Int) -> Int {
        return num1 % num2
    }
    }

let calculaotor = Calculaotor()

print(calculaotor.add(num1: 3, num2: 4))
print(calculaotor.add(num1: 2.5, num2: 2.5))

print(calculaotor.sub(num1: 125, num2: 25))
print(calculaotor.sub(num1: 12.5, num2: 2.2))

print(calculaotor.mul(num1: 3, num2: 4))
print(calculaotor.mul(num1: 4.5, num2: 3))

print(calculaotor.div(num1: 5, num2: 2))

print(calculaotor.rest(num1: 15 , num2: 7))

//page 3에 lv3과제 별도로 작성
