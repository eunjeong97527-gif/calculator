//: [Previous](@previous)

/*import Foundation

var greeting = "Hello, playground"
*/
//: [Next](@next)

//LV3 과제

class AddOperation {
    var num1: Int
    var num2: Int
    init(num1: Int, num2:Int) {
        self.num1 = num1
        self.num2 = num2
    }
    func plus() -> Int {
 return num1 + num2
    }
    }
 
class SubstractOperation {
    var num1: Int
    var num2: Int
    init(num1: Int, num2:Int) {
        self.num1 = num1
        self.num2 = num2
    }
    func minus() -> Int {
 return num1 - num2
    }
    }

class MultiplyOperation {
    var num1: Int
    var num2: Int
    init(num1: Int, num2:Int) {
        self.num1 = num1
        self.num2 = num2
    }
    func multiply() -> Int {
        return num1 * num2
    }
}

    class DivideOperation {
        var num1: Int
        var num2: Int
        init(num1: Int, num2:Int) {
            self.num1 = num1
            self.num2 = num2
        }
        func divide() -> Double {
     return Double(num1) / Double(num2)
        }
    }

    class Calculaotor {
        func add(num1: Int, num2: Int) -> Int {
            let addOperation = AddOperation(num1: num1, num2: num2)
            return addOperation.plus()
        }
        
        func sub(num1: Int, num2: Int) -> Int {
            let substract = SubstractOperation(num1: num1, num2: num2)
            return substract.minus()
        }
        
        func mul(num1: Int, num2: Int) -> Int {
            let multiplyOperation = MultiplyOperation(num1: num1, num2: num2)
            return multiplyOperation.multiply()
        }
        
        func div(num1: Int, num2: Int) -> Double {
            let  divideOperation = DivideOperation(num1: num1, num2: num2)
            return divideOperation.divide()
        }
    }

let calculator = Calculaotor()
    
print(calculator.add(num1: 5, num2: 2))
print(calculator.sub(num1: 5, num2: 2))
print(calculator.mul(num1: 5, num2: 2))
print(calculator.div(num1: 4, num2: 3))
